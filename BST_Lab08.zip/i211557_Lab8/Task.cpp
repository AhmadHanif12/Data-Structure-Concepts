#include <iostream>
#include <cmath>
using namespace std;

class node
{
public:
    int data;
    node *left;
    node *right;

    node(int value = -1)
    {
        data = value;
        left = NULL;
        right = NULL;
    }

    node(const node &temp)
    {
        data = temp.data;
        left = temp.left;
        right = temp.right;
    }

    bool isFull()
    {
        if (right && left)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    bool isNoChild()
    {
        if (!right && !left)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    void display()
    {
        cout << "Data is: " << data;
    }
};

class BST
{
private:
    node *root;
    int numNodes;

public:
    BST()
    {
        root = NULL;
        numNodes = 0;
    }

    bool isEmpty()
    {
        if (!root)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    node *returnRoot() // getter
    {
        return root;
    }

    void insert(int val)
    {
        node *current = root;
        if (!root)
        {
            root = new node(val);
            numNodes++;
        }
        else
        {
            while (current)
            {
                if (current->data == val)
                {
                    cout << "\nData already present in the tree !\n";
                    return;
                }

                if (current->data < val)
                {
                    if (!current->right)
                    {
                        current->right = new node(val);
                        numNodes++;
                        return;
                    }
                    current = current->right;
                }
                else if (current->data > val)
                {
                    if (!current->left)
                    {
                        current->left = new node(val);
                        numNodes++;
                        return;
                    }
                    current = current->left;
                }
            }
        }
    }
    bool Search(int val)
    {
        node *current = root;
        while (current)
        {
            if (current->data == val)
            {
                return true;
            }

            else if (current->data < val)
            {

                current = current->right;
            }
            else if (current->data > val)
            {
                current = current->left;
            }
        }

        return false;
    }

    void inorderTraversal(node *input)
    {
        if (input)
        {
            inorderTraversal(input->left);
            cout << input->data << " ";
            inorderTraversal(input->right);
        }
    }

    int findMax()
    {
        if (!root)
        {
            cout << "\nTree is Empty!\n";
            return 0;
        }
        node *current = root;
        while (current->right)
        {
            current = current->right;
        }
        return current->data;
    }

    int findMin()
    {
        if (!root)
        {
            cout << "\nTree is Empty!\n";
            return 0;
        }
        node *current = root;
        while (current->left)
        {
            current = current->left;
        }
        return current->data;
    }

    int returnNodeCount()
    {
        return numNodes;
    }

    ~BST(){}
};

int main()
{

    BST T1;
    T1.insert(10);
    T1.insert(15);
    T1.insert(5);
    T1.insert(3);
    T1.insert(18);
    cout<<"\nDisplaying :\n";
    T1.inorderTraversal(T1.returnRoot());

    cout<<"\n\nMax is: "<<T1.findMax()<<endl;
    cout<<"Min is: "<<T1.findMin()<<endl;

    if(T1.Search(5))
    {
        cout<<"\n\nFound!!\n";
    }
    else
    {
        cout<<"\nNot Found!!\n";
    }

}